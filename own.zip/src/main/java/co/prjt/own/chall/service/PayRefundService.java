package co.prjt.own.chall.service;

//실제 돈이 들어오고 나가는 지불 환급 내역
public interface PayRefundService {
	//결제 및 환급 시 insert
	//회원별 조회
	//도전별 조회
	//전체 조회
}
