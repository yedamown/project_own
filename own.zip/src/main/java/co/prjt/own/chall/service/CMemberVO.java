package co.prjt.own.chall.service;

import lombok.Data;

@Data
public class CMemberVO {
	String userId;
	String memNickname;
	int memAmt;
	int memAcc;
	String memBank;
	String memIntro;
	String memAccname;
}
