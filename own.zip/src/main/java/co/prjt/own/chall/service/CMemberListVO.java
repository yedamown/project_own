package co.prjt.own.chall.service;

import lombok.Data;

@Data
public class CMemberListVO {
	String memListNo;
	String userId;
	String challNo;
	String memStatus;
}
