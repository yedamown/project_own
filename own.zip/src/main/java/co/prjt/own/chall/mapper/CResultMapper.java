package co.prjt.own.chall.mapper;

public interface CResultMapper {

}
