package co.prjt.own.chall.service;

public interface CResultService {
	//성공률 입력
	int insertCResult(CReportVO vo);
	
	//도전별로 보기
	//멤버별로 보기
}
