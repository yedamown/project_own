package co.prjt.own.common.service;

import lombok.Data;

@Data
public class MultimediaVO {
	String mediaNo;
	String mediaRealFile;
	String mediaServerFile;
	String mediaFilePath;
	String identifyId;
	String mediaCategory;
	String mediaTurn;
	String ino;
}
