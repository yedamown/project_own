package co.prjt.own.common.mapper;

import java.util.List;

import co.prjt.own.common.service.ExersubVO;

public interface CommonMapper {
	public List<ExersubVO> getListExersub();
}
