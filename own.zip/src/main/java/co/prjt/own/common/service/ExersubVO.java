package co.prjt.own.common.service;

import lombok.Data;

@Data
public class ExersubVO {
	public String exersubNo;
	public String exersubKind;
	public int kcal;
	public String exersubName;
}
