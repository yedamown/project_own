package co.prjt.own.sns.service;

import java.util.Date;

import lombok.Data;

@Data
public class SBoardVO {
	String snsBoardNo;
	String snsBoardContent;
	Date snsBoardDate;
	String snsNickname;
	String snsAccountNo;
	
}
