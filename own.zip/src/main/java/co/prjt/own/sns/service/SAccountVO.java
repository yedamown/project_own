package co.prjt.own.sns.service;

import lombok.Data;

@Data
public class SAccountVO {
	String snsNickname;
	String snsProfile;
	String snsBoardNo;
	String snsWebsite;
	String snsAccountNo;

}
