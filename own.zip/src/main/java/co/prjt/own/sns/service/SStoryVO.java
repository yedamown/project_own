package co.prjt.own.sns.service;

import java.util.Date;

import lombok.Data;

@Data
public class SStoryVO {
	String snsStroyNo;
	String snsNickname;
	Date snsStoryDate;
	String snsSatus;
	String snsAccountNo;
	
}
