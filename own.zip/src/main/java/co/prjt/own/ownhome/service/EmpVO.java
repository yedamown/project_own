package co.prjt.own.ownhome.service;

public class EmpVO {
	public String employeeId;
}
